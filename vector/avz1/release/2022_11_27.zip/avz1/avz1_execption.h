/*
 * @Coding: utf-8
 * @Author: vector-wlc
 * @Date: 2021-11-15 11:06:42
 * @Description:
 */

#ifndef __AVZ1_EXCEPTION_H__
#define __AVZ1_EXCEPTION_H__
#include <avz.h>
namespace AvZ {
using Exception = AException;
}

#endif