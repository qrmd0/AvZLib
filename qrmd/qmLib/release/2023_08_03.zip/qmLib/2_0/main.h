#ifndef __2_0__
#define __2_0__

#include "fighting.h"
#include "global.h"
#include "memory.h"
#include "tool.h"

#endif