#ifndef __2_0__
#define __2_0__

#include "fighting.h"
#include "global.h"
#include "memory.h"
#include "paint.h"
#include "tool.h"
#include "drawBar.h"
#include "click.h"

#endif