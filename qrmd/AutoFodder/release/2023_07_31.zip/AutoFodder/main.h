/*
 * @Author: qrmd
 * @Date: 2023-07-31 13:13:32
 * @LastEditors: qrmd
 * @LastEditTime: 2023-07-31 13:16:09
 * @Description:自动垫材
 */

#ifndef _AUTOFODDER
#define _AUTOFODDER

#include "avz.h"

#if __AVZ_VERSION__ <= 221001

#else
#include "AutoFodder_2_0.h"
#endif

#endif